__author__ = """OceanProtocol"""
__version__ = '0.5.5'

#  Copyright 2018 Ocean Protocol Foundation
#  SPDX-License-Identifier: Apache-2.0
